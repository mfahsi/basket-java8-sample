package com.mf.mmstore.page;

import com.mf.store.page.Page;
import com.mf.store.page.PageDataImpl;
import com.mf.store.page.PageIndexmpl;
import com.mf.store.page.RecordPosition;
import com.mf.store.page.entry.DataEntry;
import com.mf.store.page.entry.IndexEntry;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by mdfah_000 on 04/06/2017.
 */

public class PageDataTest {


    @Test
    public void should_write_index_then_load_all_file() throws IOException {

        Page data = new PageDataImpl("page.txt",50);
        data.write(new DataEntry(15564,"content"));
        DataEntry entry= data.readById(15564);
        Assert.assertEquals("content",entry.userRecord());
    }

    @Test
    public void should_transform_entry_correctly() throws IOException {

        RecordPosition data = new RecordPosition(16,25);
        IndexEntry idx = new IndexEntry(123,data);
        RecordPosition back = idx.userRecord();
        Assert.assertEquals(data,back);
    }
       @Test
        public void should_write_index_and_read_it() throws IOException {

           PageIndexmpl idx = new PageIndexmpl("page",50);
           idx.addToIndex(123,new RecordPosition(0,15));
           RecordPosition data = new RecordPosition(16,25);
           idx.addToIndex(850,data);

           RecordPosition ps = idx.readIndex(850);
           Assert.assertEquals(ps,data);
        }

        // some more tests might go here
    }


