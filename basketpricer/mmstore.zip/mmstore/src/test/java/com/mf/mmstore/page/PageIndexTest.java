package com.mf.mmstore.page;

import com.mf.store.page.entry.IndexEntry;
import com.mf.store.page.PageIndexmpl;
import com.mf.store.page.RecordPosition;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by mdfah_000 on 04/06/2017.
 */

public class PageIndexTest {


    @Test
    public void should_write_index_then_load_all_file() throws IOException {

        PageIndexmpl idx = new PageIndexmpl("page",50);
        idx.addToIndex(123,new RecordPosition(0,15));
        RecordPosition data = new RecordPosition(16,25);
        idx.addToIndex(850,data);
        Assert.assertEquals(data,idx.readIndex(850));
        idx = new PageIndexmpl("page",50);
        Assert.assertEquals(data,idx.readIndex(850));
    }

    @Test
    public void should_transform_entry_correctly() throws IOException {

        RecordPosition data = new RecordPosition(16,25);
        IndexEntry idx = new IndexEntry(123,data);
        RecordPosition back = idx.userRecord();
        Assert.assertEquals(data,back);
    }
       @Test
        public void should_write_index_and_read_it() throws IOException {

           PageIndexmpl idx = new PageIndexmpl("page",50);
           idx.addToIndex(123,new RecordPosition(0,15));
           RecordPosition data = new RecordPosition(16,25);
           idx.addToIndex(850,data);

           RecordPosition ps = idx.readIndex(850);
           Assert.assertEquals(ps,data);
        }

        // some more tests might go here
    }


