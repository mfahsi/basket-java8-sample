package com.mf.store.page;

import java.io.IOException;
import java.util.*;


/**
 * This class controls access to the MemoryMappedFile.
 * Since the MMF is not threadsafe, reentrant read/write locking is used
 * to allow concurrent reading and safe writing.
 * 
 * @author jens
 *
 */
public class PageIndexmpl extends MemoryMappedPageImpl<RecordPosition,IndexEntry> implements MemoryMappedPage<IndexEntry>, PageIndex, AutoCloseable {

	private Map<Long,RecordPosition> pageIndexCache;

	public PageIndexmpl(String filePath, long totalSize) throws IOException {
       super(filePath,totalSize);
      // initCache();
	}

	@Override
	public IndexEntry read(RecordPosition position) {
		byte [] record = read(position.getRecordStartOffset(),position.recordSize());
		return new IndexEntry(record) ;

	}

	void addToIndex(IndexEntry entry) {
		write(entry);
		pageIndexCache.put(entry.id(),entry.userRecord());
	}

	@Override
	public void addToIndex(long recordId, RecordPosition position) {
		addToIndex(new IndexEntry(recordId,position));
	}

	@Override
	public RecordPosition readIndex(long recordID) {

		return pageIndexCache.get(recordID);
	}

	@Override
	IndexEntry fromDbRecordBytes(byte[] systemRecordAsBytes) {
		return new IndexEntry(systemRecordAsBytes);
	}

	protected void initCache() throws IOException {
		Set<IndexEntry> current = loadAllData(25);
		pageIndexCache =new HashMap<>();
		System.out.println("inmem"+ pageIndexCache);
		for(IndexEntry entry:current){
			pageIndexCache.put(entry.id(),entry.userRecord());
		}
	}




}
