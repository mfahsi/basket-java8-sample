package com.mf.store.page;

public interface MemoryMappedPage<R>
{
	R read(RecordPosition position);
	void write (R recordEntry);
}
