package com.mf.store.page;
public class IndexEntry extends Entry<RecordPosition>{
    IndexEntry(){
        super();
    }
    public IndexEntry(long id, RecordPosition data) {
        super(id, data);
    }

    public IndexEntry(byte [] datainfile) {
        super(datainfile);
    }

    @Override
    IndexEntry fromDbRecordBytes(byte[] systemRecordAsBytes) {
        return new IndexEntry(systemRecordAsBytes);
    }

    @Override
    RecordPosition fromBytes(byte[] recordAsBytes) {
        return RecordPosition.fromBytes(recordAsBytes);
    }

    @Override
    byte[] toBytes(RecordPosition data) {
        return RecordPosition.toBytes(data);
    }
}