package com.mf.store.page;

import com.mf.store.page.entry.DataEntry;
import com.mf.store.page.entry.Entry;
import com.mf.store.page.entry.IndexEntry;
import com.mf.store.page.mmfile.MemoryMappedFile;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.ParameterizedType;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;


/**
 * This class controls access to the MemoryMappedFile.
 * Since the MMF is not threadsafe, reentrant read/write locking is used
 * to allow concurrent reading and safe writing.
 * 
 * @author jens
 *
 */
abstract class MemoryMappedPageImpl<T,R extends Entry<T>> implements MemoryMappedPage<R>, AutoCloseable {
	/**
	 * @author Jens Raaby MemoryMappedPage the memory mapped file privately
	 */
	private MemoryMappedFile memory;
	private RandomAccessFile raf;
	private Path path;
	PageIndex index;

	// Locking: parallel reads are OK.
	private ReentrantReadWriteLock lock = new ReentrantReadWriteLock(true);
	private ReadLock r = lock.readLock();
	private WriteLock w = lock.writeLock();
	private boolean isOpen=false;

	protected void initCache() throws IOException {
	}

	boolean isIndexed(){
		return false;
	}

	/**
	 * 
	 * @param filePath
	 *            The path to a file for storage
	 * @param totalSize
	 *            Maximum addressable space. When the file is full, it can
	 *            increase in size. But I think an exception should be thrown if
	 *            the initial size is > the total
	 */
	public MemoryMappedPageImpl(String filePath, long totalSize) {
//		w.lock();
		try {
			// memory not persistent: file deleted when program completes!
			File storeFile = new File(filePath);
			//storeFile.deleteOnExit();
			path = Paths.get(filePath);
			initCache(); //before map to memory
			// Preallocate Set file size (bytes)
			raf = new RandomAccessFile(storeFile, "rw");
            raf.setLength(totalSize); // e.g size = 2048, size will be 2 KB
			FileChannel fc = raf.getChannel();
			System.out.println("MemoryMappedPage initializing: file size: " + fc.size());
			// n.b. buffer sets the initial position - 0 should be an OK start
			memory = new MemoryMappedFile(fc, FileChannel.MapMode.READ_WRITE,
					0, totalSize);
			if(isIndexed()) {
				index = new PageIndexmpl(filePath + ".idx", totalSize);//loaded on creation
			}
			isOpen=true;
		} catch (IOException ex) {
			// TODO: handle exceptions
			ex.printStackTrace();
		} catch (IndexOutOfBoundsException ex) {
			// TODO: handle exceptions
			ex.printStackTrace();
		} finally {
//			w.unlock();
		}
	}

	/**
	 * Read takes a position
	 *
	 * @param position
	 *            The starting position in the address space
	 *
	 * @param length
	 *            The byte length - assumed to fit within the memory file (the
	 *            calling method should check this)
	 */
	public byte[] read(Long position, int length) {
		r.lock();
		try {
			byte[] block = new byte[length];
			memory.get(block, position);

			return block;
		} finally {
			r.unlock();
		}
	}

	public Long readLong(Long position) {
		r.lock();
		try {
			byte[] block = new byte[1];
			 memory.get(block, position);
			 return ByteUtils.bytesToLong(block);
		} finally {
			r.unlock();
		}
	}

	public Set<IndexEntry> generateIndex() throws IOException {
		r.lock();
		try {
			Set<IndexEntry> fileIndex = new HashSet<>();
			try (SeekableByteChannel sbc = Files.newByteChannel(path, EnumSet.of(StandardOpenOption.READ,StandardOpenOption.WRITE,StandardOpenOption.CREATE))) {
				long offsetPrev = 0;
				long offset = 0;
				ByteBuffer buf = ByteBuffer.allocate(100);
				String encoding = System.getProperty("file.encoding");
				while (sbc.read(buf) > 0) {
					buf.rewind();
					byte[] bytes = buf.array();
					for (long i = 0; i < bytes.length; i++) {
						if (bytes[(int)i] == Entry.RECORD_END_MARKER) {
							offset = i;
							long id = readLong((long) offsetPrev);
							fileIndex.add(new IndexEntry(id, new RecordPosition(offsetPrev, offset - 1)));
						}
					}
					buf.flip();
				}
				return  fileIndex;
			}

		} finally {
			r.unlock();
		}
	}


	abstract R fromDbRecordBytes(byte[] systemRecordAsBytes) ;


//TODO
	public Set<R> loadAllData(int fixedSize) throws IOException {
		r.lock();
		try {
			Set<R> fileIndex = new HashSet<>();

			//SeekableByteChannel sbc = raf.getChannel()
			try (SeekableByteChannel sbc=Files.newByteChannel(path, EnumSet.of(StandardOpenOption.READ,StandardOpenOption.CREATE,StandardOpenOption.WRITE))) {
				long offsetPrev = 0;
				long offset = 0;
				ByteBuffer buf = ByteBuffer.allocate(fixedSize);
				buf.clear();
				System.out.println("loading ="+sbc.size());
				while (sbc.read(buf) > 0) {
					//buf.flip();
					byte[] bytes = buf.array();
					offset=offset+bytes.length;
					if(bytes.length == fixedSize) {
						fileIndex.add(fromDbRecordBytes(bytes));
					}
					buf.clear();
					buf.flip();
					}

				}
				return  fileIndex;
			}
			finally {
			  r.unlock();
		    }
	   }


	public void write(Long position, byte[] value) {
		w.lock();
		try {
			memory.put(value, position);
	     } catch (BufferOverflowException ex) {
			ex.printStackTrace();
		} catch (IndexOutOfBoundsException ex) {
			ex.printStackTrace();
		} finally {
			w.unlock();
		}

	}

	public void append(R entry) {
		w.lock();
		try {
			byte [] recordwithseparator = entry.systemRecord();
			RecordPosition expectedPosition = new RecordPosition(memory.position(),(memory.position()+recordwithseparator.length-1));
			memory.put(recordwithseparator);
			if(index != null){
				index.write(new IndexEntry(entry.id(),expectedPosition));
			}
		} catch (BufferOverflowException ex) {
			ex.printStackTrace();
		} catch (IndexOutOfBoundsException ex) {
			ex.printStackTrace();
		} finally {
			w.unlock();
		}

	}

	@SuppressWarnings("unchecked")
	R entryInstance() {
		// Get the class name of this instance's type.
		ParameterizedType pt
				= (ParameterizedType) getClass().getGenericSuperclass();
		// You may need this split or not, use logging to check
		String parameterClassName
				= pt.getActualTypeArguments()[0].toString().split("\\s")[1];
		// Instantiate the Parameter and initialize it.
		try {
			return (R) Class.forName(parameterClassName).newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	final public R read(RecordPosition position) {
		byte [] record = read(position.getRecordStartOffset(),position.recordSize());
		return fromDbRecordBytes(record);
	}

	public R readById(long recordId) {
		if(index == null) throw new UnsupportedOperationException("Index feature needed");
		RecordPosition position = index.readIndex(recordId);
		if(position != null){
			return read(position);
		}
		return null;
	}

	@Override
	public void write(R recordEntry) {
		append(recordEntry);
	}

	@Override
	public void close() throws Exception {
		if(isOpen) {
			try {
				raf.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			isOpen=false;
		}
	}
}
