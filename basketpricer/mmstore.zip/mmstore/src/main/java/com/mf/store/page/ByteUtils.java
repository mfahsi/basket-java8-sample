package com.mf.store.page;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class ByteUtils {
    public static final Charset charset= StandardCharsets.UTF_8;
    private static ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);

    public static byte[] longToBytes(long x) {
        buffer.putLong(0, x);
        return buffer.array();
    }

    public static long bytesToLong(byte[] bytes) {
        buffer.put(bytes, 0, bytes.length);
        buffer.flip();//need flip
        return buffer.getLong();
    }

    public static String bytesToString(byte[] bytes) {

        return new String(bytes, StandardCharsets.UTF_8);
    }

    public static byte[] stringToBytes(String data) {
       return data.getBytes(StandardCharsets.UTF_8);
    }
}