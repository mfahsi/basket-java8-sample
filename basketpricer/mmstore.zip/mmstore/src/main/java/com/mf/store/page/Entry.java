package com.mf.store.page;

import org.apache.commons.lang3.ArrayUtils;

import java.lang.reflect.ParameterizedType;
import java.nio.ByteBuffer;

/**
 * Created by mdfah_000 on 04/06/2017.
 */
abstract class Entry<T> {
    static final byte RECORD_END_MARKER=36;
    private long id;
    private byte[] data;
    private byte [] storeRecord;//idUserRecordNumber

     Entry(){
     }

     void fill(byte [] recordDataIncSeparator){
         this.storeRecord=recordDataIncSeparator;
         ByteBuffer buffer = ByteBuffer.allocate(recordDataIncSeparator.length);
         buffer.put(recordDataIncSeparator);
         buffer.flip();
         this.id=buffer.getLong();
         this.data=userRecordBytes();
     }

    public Entry(long id, T userObject){
        this.id=id;
        this.data=toBytes(userObject);
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES+data.length+1);
        buffer.putLong(id);
        buffer.put(data);
        buffer.put(RECORD_END_MARKER);
        this.storeRecord = buffer.array();
        buffer.flip();
    }

    public Entry(byte [] recordDataIncSeparator){
       fill(recordDataIncSeparator);
    }

    abstract Entry fromDbRecordBytes(byte[] systemRecordAsBytes);

    public long id(){
        return id;
    }

    abstract T fromBytes(byte [] userDataAsBytes);
    abstract byte [] toBytes(T userData);

    long systemRecordSize(){
        return storeRecord.length;
    }

    byte[] systemRecord(){
        return storeRecord;
    }

    public byte [] userRecordBytes()
    {
        return ArrayUtils.subarray(storeRecord,Long.BYTES,storeRecord.length-1);
    }

    public T userRecord()
    {
        return fromBytes(userRecordBytes());

    }

}
