package com.mf.store.page;

import com.mf.store.page.RecordPosition;
import com.mf.store.page.entry.DataEntry;

public interface Page extends MemoryMappedPage<DataEntry>
{
	DataEntry readById(long recordId);
}
