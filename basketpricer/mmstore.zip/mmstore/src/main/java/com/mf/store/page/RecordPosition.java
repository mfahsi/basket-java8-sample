package com.mf.store.page;

import java.nio.ByteBuffer;

/**
 * Created by mdfah_000 on 04/06/2017.
 */
public class RecordPosition {
    private long recordStartOffset;
    private long recordEndOffset;

    public RecordPosition(long recordStartOffset, long recordEndOffset) {
        this.recordStartOffset = recordStartOffset;
        this.recordEndOffset = recordEndOffset;
    }
    public RecordPosition(String str) {
        this.recordStartOffset = Long.parseLong(str.split(":")[0]);
        this.recordEndOffset = Long.parseLong(str.split(":")[1]);
    }

    @Override
    public String toString() {
        return recordStartOffset +":"+recordEndOffset ;
    }

    public int recordSize(){
        return (int) (recordEndOffset-recordStartOffset+1);
    }

    public long getRecordStartOffset() {
        return recordStartOffset;
    }

    static RecordPosition fromBytes(byte[] recordAsBytes) {
        /*ByteBuffer buffer = ByteBuffer.allocate(3);
        buffer.put(recordAsBytes);
        buffer.flip();
        long l1= buffer.getLong();*/
        return new RecordPosition(ByteUtils.bytesToString(recordAsBytes));
    }

    static byte[] toBytes(RecordPosition record) {
       return ByteUtils.stringToBytes(record.toString());
    }

    public void setRecordStartOffset(long recordStartOffset) {
        this.recordStartOffset = recordStartOffset;
    }

    public long getRecordEndOffset() {
        return recordEndOffset;
    }

    public void setRecordEndOffset(long recordEndOffset) {
        this.recordEndOffset = recordEndOffset;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RecordPosition that = (RecordPosition) o;

        if (recordStartOffset != that.recordStartOffset) return false;
        return recordEndOffset == that.recordEndOffset;
    }

    @Override
    public int hashCode() {
        int result = (int) (recordStartOffset ^ (recordStartOffset >>> 32));
        result = 31 * result + (int) (recordEndOffset ^ (recordEndOffset >>> 32));
        return result;
    }

}
