package com.mf.store.page;


/**
 * This class controls access to the MemoryMappedFile.
 * Since the MMF is not threadsafe, reentrant read/write locking is used
 * to allow concurrent reading and safe writing.
 * 
 * @author jens
 *
 */
public class DataPageImpl extends MemoryMappedPageImpl<String,DataEntry> implements MemoryMappedPage<DataEntry>, AutoCloseable {

	public DataPageImpl(String filePath, long totalSize) {
       super(filePath,totalSize);
	}

	@Override
	DataEntry fromDbRecordBytes(byte[] systemRecordAsBytes) {
		return new DataEntry(systemRecordAsBytes);
	}

	public DataEntry read(RecordPosition position) {
		byte [] record = read(position.getRecordStartOffset(),position.recordSize());
		return new DataEntry(record) ;
	}

}
