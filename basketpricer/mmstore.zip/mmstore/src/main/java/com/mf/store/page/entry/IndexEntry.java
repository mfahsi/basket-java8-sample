package com.mf.store.page.entry;

import com.mf.store.page.ByteUtils;
import com.mf.store.page.RecordPosition;

import java.nio.ByteBuffer;

public class IndexEntry extends Entry<RecordPosition> {

    IndexEntry(){
        super();
    }

    public IndexEntry(long id, RecordPosition data) {
        super(id, data);
    }

    public IndexEntry(byte [] datainfile) {
        super(datainfile);
    }

    @Override
    RecordPosition userRecordFromBytes(byte[] recordAsBytes) {
        return new RecordPosition(ByteUtils.bytesToString(recordAsBytes));
    }

    @Override
    byte[] userRecordToBytes(RecordPosition record) {
        return ByteUtils.stringToBytes(record.toString());
    }
}