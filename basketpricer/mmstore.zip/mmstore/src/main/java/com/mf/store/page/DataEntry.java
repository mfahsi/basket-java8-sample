package com.mf.store.page;

import java.nio.charset.StandardCharsets;

/**
 * Created by mdfah_000 on 04/06/2017.
 */
public class DataEntry extends Entry<String> {
    DataEntry(){
        super();
    }
    public DataEntry(long id, String data) {
        super(id, data);
    }

    public DataEntry(byte [] datainfile) {
        super(datainfile);
    }

    @Override
    DataEntry fromDbRecordBytes(byte[] systemRecordAsBytes) {
        return new DataEntry(systemRecordAsBytes);
    }

    @Override
    String fromBytes(byte[] recordAsBytes) {
        return new String(recordAsBytes, StandardCharsets.UTF_8);
    }

    @Override
    byte[] toBytes(String data) {
        return data.getBytes(StandardCharsets.UTF_8);
    }
}
