package com.mf.store.page;


import com.mf.store.page.entry.DataEntry;

import java.io.IOException;

/**
 * This class controls access to the MemoryMappedFile.
 * Since the MMF is not threadsafe, reentrant read/write locking is used
 * to allow concurrent reading and safe writing.
 * 
 * @author jens
 *
 */
public class PageDataImpl extends MemoryMappedPageImpl<String,DataEntry> implements Page, AutoCloseable {



	public PageDataImpl(String filePath, long totalSize) throws IOException {
       super(filePath,totalSize);

	}

	@Override
	DataEntry fromDbRecordBytes(byte[] systemRecordAsBytes) {
		return new DataEntry(systemRecordAsBytes);
	}



	boolean isIndexed(){
		return true;
	}

}
