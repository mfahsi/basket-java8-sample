package com.mf.store.page;

public interface PageIndex
{
	public void addToIndex(long recordId, RecordPosition position);
	RecordPosition readIndex(long recordID);

}
