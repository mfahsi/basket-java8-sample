package com.mf.store.page;

import com.mf.store.page.entry.DataEntry;
import com.mf.store.page.entry.IndexEntry;

public interface PageIndex extends MemoryMappedPage<IndexEntry>
{
	public void addToIndex(long recordId, RecordPosition position);
	RecordPosition readIndex(long recordID);

}
