package com.mf.store.page.entry;

import com.mf.store.page.ByteUtils;
import org.apache.commons.lang3.ArrayUtils;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * Created by mdfah_000 on 04/06/2017.
 */
abstract public class Entry<T> {
    public static final Charset charset= StandardCharsets.UTF_8;
    public static final byte RECORD_ID_MARKER=36;
    public static final byte RECORD_END_MARKER=0;
    private byte[] recordId;
    private byte[] data;
    private byte [] storeRecord;//idUserRecordNumber

     Entry(){
     }

     protected Entry getInstance(){
         try {
             return getClass().newInstance();
         } catch (InstantiationException e) {
             e.printStackTrace();
         } catch (IllegalAccessException e) {
             e.printStackTrace();
         }
         return null;
     }

    public Entry(long id, T userObject){
       fillFromUserRecord(id,userObject);
    }

    public Entry(byte [] recordDataIncSeparator){
       fillFromStoreRecord(recordDataIncSeparator);
    }

    private int indexOfComma(byte [] row)
    {
        for(int i=0;i<row.length;i++){
            if(row[i]==RECORD_ID_MARKER){
                return i;
            }
        }
        return -1;
    }
    final void fillFromStoreRecord(byte [] recordDataIncSeparator){
        this.storeRecord=recordDataIncSeparator;
        ByteBuffer buffer = ByteBuffer.allocate(recordDataIncSeparator.length);
        buffer.put(recordDataIncSeparator);
        buffer.flip();
        int comma=indexOfComma(recordDataIncSeparator);
        buffer.get(recordId,0,(comma-1));
        buffer.get(data,(comma+1),storeRecord.length-2);;
    }

    final void fillFromUserRecord(long id, T userObject){
        this.recordId =ByteUtils.stringToBytes(Long.toString(id));
        this.data= userRecordToBytes(userObject);
        ByteBuffer buffer = ByteBuffer.allocate(recordId.length+data.length+2);
        buffer.put(recordId);
        buffer.put(RECORD_ID_MARKER);
        buffer.put(data);
        buffer.put(RECORD_END_MARKER);
        this.storeRecord = buffer.array();
        buffer.flip();
    }


    //abstract Entry entryFromStoreRecordWithSeparator(byte[] systemRecordAsBytes);

    public final Entry entryFromStoreRecordWithSeparator(byte[] systemRecordAsBytes) {
       Entry entry = getInstance();
       entry.fillFromStoreRecord(systemRecordAsBytes);
       return entry;
    }

    abstract T userRecordFromBytes(byte [] userDataAsBytes);

    abstract byte [] userRecordToBytes(T userData);

    final public long id(){
        String id = ByteUtils.bytesToString(recordId);
        return Long.parseLong(id);
    }

    final long systemRecordSize(){
        return storeRecord.length;
    }

    final public byte[] systemRecord(){
        return storeRecord;
    }

    final public byte [] userRecordBytes()
    {
        return ArrayUtils.subarray(storeRecord,recordId.length+1,storeRecord.length-1);
    }

    public T userRecord()
    {
        return userRecordFromBytes(userRecordBytes());

    }

}
